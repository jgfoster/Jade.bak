To run the Jadeite.exe: 

- Download the entire runtime folder to a windows client
- setup a Rowan-enabled gemstone server from https://github.com/dalehenrich/Rowan
- Run the Jadeite.exe from within the downloaded directory.
- Report any major issues on the Rowan project.
